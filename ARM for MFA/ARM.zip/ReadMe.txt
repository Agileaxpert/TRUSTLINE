Fixes for following points is released:

1) TASK-0581 - OTP auth needed in mobile.

ARM Configuration:
1) Create new folder for ARM. Use appsettings.json from previous release.

Please find the below link for Mobile APK

https://agilelabs.sharepoint.com/:f:/s/AxpertMobile/EgYyKxYTjidDgGzZU3gOhGQB4Vhwg__o1PNS5flwPMhUpg?e=Ki7Lq3
